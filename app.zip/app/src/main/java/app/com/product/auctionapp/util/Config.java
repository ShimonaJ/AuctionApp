package app.com.product.auctionapp.util;



/**
 * Created by Shimona on 9/24/2016.
 */

public class Config {
    public static final String USERID="UserId";

}
